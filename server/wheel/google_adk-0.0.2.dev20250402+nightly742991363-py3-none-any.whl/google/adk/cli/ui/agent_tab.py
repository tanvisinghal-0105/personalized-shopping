# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import importlib
import json
import logging
import os
from typing import Optional

from google.adk.agents.base_agent import BaseAgent
from google.adk.agents.llm_agent import Agent
from google.adk.agents.llm_agent import LlmAgent
from google.adk.agents.run_config import StreamingMode
from google.adk.cli.utils import create_empty_state
from google.adk.cli.utils import envs
from google.adk.sessions.session import Session
import pandas as pd
import streamlit as st

from . import agent_graph
from . import app_context
from . import pending_events
from . import remote_mode

logger = logging.getLogger(__name__)

_ENV_VARIABLES: dict[str, str] = {
    'GOOGLE_GENAI_USE_VERTEXAI': (
        'Choose model provider: 0 for Google AI, 1 for Vertex.'
    ),
    'GOOGLE_API_KEY': (
        'Google API Key, required if GOOGLE_GENAI_USE_VERTEXAI=0.'
    ),
    'GOOGLE_CLOUD_PROJECT': (
        'Google Cloud Project ID, required if GOOGLE_GENAI_USE_VERTEXAI=1.'
    ),
    'GOOGLE_CLOUD_LOCATION': (
        'Google Cloud Location, required if GOOGLE_GENAI_USE_VERTEXAI=1.'
    ),
    'GOOGLE_CLOUD_AGENT_ENGINE_ID': (
        'Google Cloud Agent Engine ID, set if using Vertex AI Session Service.'
    ),
    'AF_TRACE_TO_CLOUD': (
        'Whether to export trace to Google Cloud. 1 for yes, otherwise no.'
    ),
}
"""Key environment variables and the descriptions."""

_TEST_USER_ID = 'test_user'


def on_demo_name_change():
  demo_name: Optional[str] = st.session_state.demo_name
  if app_context.is_remote_mode():
    st.query_params.app = demo_name
    reset_session()
    logger.info('remote agent is connected.')
  elif demo_name == app_context.CONNECT_REMOTE_SERVER_DEMO_NAME:
    connect_remote_server()
  elif demo_name:
    st.query_params.app = demo_name
    import_agent_module()
    reset_session()
  else:
    st.query_params.pop('app', None)


def on_streaming_change():
  if st.session_state.streaming == StreamingMode.SSE:
    st.toast('Server socket streaming is always using Gemini 2.0')
    st.session_state.response_modalities = ['TEXT']
  elif st.session_state.streaming == StreamingMode.BIDI:
    st.toast('Bidi streaming is always using Gemini 2.0')
    st.session_state.response_modalities = ['AUDIO']


# Using fragment so switching to server streaming doesn't rerun the page.
@st.fragment
def render_streaming_options():
  streaming_options = {
      StreamingMode.NONE: 'None',
      StreamingMode.SSE: 'SSE',
      StreamingMode.BIDI: 'BIDI',
  }
  st.segmented_control(
      'Streaming',
      options=streaming_options.keys(),
      format_func=lambda option: streaming_options[option],
      selection_mode='single',
      key='streaming',
      on_change=on_streaming_change,
  )

  if st.session_state.streaming:
    st.multiselect(
        'Response Modalities',
        ['TEXT', 'AUDIO'],
        key='response_modalities',
    )
  if st.session_state.streaming == StreamingMode.BIDI:
    if not st.session_state.is_live:
      if st.button('Start Streaming'):
        st.session_state.is_live = True
        st.rerun()
    else:
      if st.button('Stop Streaming'):
        st.session_state.is_live = False
        st.rerun()


def render():
  if not st.session_state.demo_name and 'app' in st.query_params:
    st.session_state.demo_name = st.query_params.app
    if app_context.is_remote_mode():
      st.session_state.session = (
          app_context.get_session_service().create_session(
              'remote_test_app',
              _TEST_USER_ID,
          )
      )
      remote_mode.create_session(
          st.session_state.session.app_name,
          st.session_state.session.user_id,
          st.session_state.session.id,
      )
      logger.info('remote agent is connected.')
    else:
      on_demo_name_change()

  if app_context.is_remote_mode():
    # Add remote server URL so the selectbox options below can be updated.
    app_context.get_remote_server_urls().add(st.session_state.demo_name)

  st.selectbox(
      'GenAI Agent Demos',
      [app_context.CONNECT_REMOTE_SERVER_DEMO_NAME]
      + sorted(list(app_context.get_remote_server_urls()))
      + get_demo_names(),
      index=None,
      placeholder='Select a demo...',
      key='demo_name',
      on_change=on_demo_name_change,
  )

  if app_context.is_remote_mode():
    st.warning(
        'Remote Mode. Some features are not available in remote mode yet.'
    )
    if st.button('Reset', use_container_width=True):
      reset_session()
    return

  if st.session_state.demo_name == app_context.CONNECT_REMOTE_SERVER_DEMO_NAME:
    return

  if not st.session_state.demo_name:
    return

  col1, col2 = st.columns(2)
  if col1.button('Definitions', use_container_width=True):
    definitions_dialog()
  if col2.button('Reload Agent', use_container_width=True):
    import_agent_module(reload=True)
  st.selectbox(
      'Sessions',
      get_saved_sessions(),
      index=None,
      on_change=load_session,
      key='selected_session',
      placeholder='Load a saved session...',
  )
  col1, col2 = st.columns(2)
  if col1.button('Reset', use_container_width=True):
    reset_session()
    st.rerun()

  if not st.session_state.agent_engine_id:
    if col2.button('Save', use_container_width=True):
      save_session_dialog()

  render_streaming_options()

  # Enable this once fixed.
  # st.button('Rerun session', use_container_width=True, key='rerun_session')

  pending_events.render_pending_events_button()

  with st.popover('Insert files'):
    st.file_uploader(
        'Files will be added to the prompt.',
        accept_multiple_files=True,
        key=st.session_state.file_uploader_key,
    )

  if st.button('Debug Info'):
    _render_debug_info_dialog()


@st.cache_resource
def get_demo_names():
  agent_folder = app_context.get_agent_folder()
  demo_names = [
      x
      for x in os.listdir(agent_folder)
      if os.path.isdir(os.path.join(agent_folder, x))
      and not x.startswith('.')
      and x != '__pycache__'
  ]
  demo_names.sort()
  logger.info('Found demos %s demos: %s', len(demo_names), demo_names)
  return demo_names


@st.dialog('Add remote server URL')
def connect_remote_server():
  remote_server_url = st.text_input(
      'Fill remote server URL:', 'http://127.0.0.1:8000'
  )
  if st.button('Connect'):
    st.session_state.demo_name = remote_server_url
    st.query_params.app = remote_server_url
    reset_session()
    # Will only add the remote server URL if reset session is successful.
    app_context.get_remote_server_urls().add(remote_server_url)
    st.rerun()


@st.dialog('Agent Definitions')
def definitions_dialog():
  agents = {}
  get_all_agents(app_context.get_root_agent(), agents)
  agent_names = list(agents.keys())
  tab_names = ['Graph'] + agent_names
  tabs = st.tabs(tab_names)
  with tabs[0]:
    st.graphviz_chart(
        agent_graph.get_agent_graph(app_context.get_root_agent(), None)
    )

  for i in range(1, len(tab_names)):
    with tabs[i]:
      agent = agents[agent_names[i - 1]]
      if isinstance(agent, BaseAgent):
        sub_agent_names = [sub_agent.name for sub_agent in agent.sub_agents]
      else:
        sub_agent_names = []
      if isinstance(agent, LlmAgent):
        tools_names = [tool.name for tool in agent.canonical_tools]
      else:
        tools_names = []
      summary = {
          'name': agent.name,
          'description': agent.description,
          'parent': agent.parent_agent.name if agent.parent_agent else '',
          'sub_agents': sub_agent_names,
          'tools': tools_names,
      }
      for key in ['model', 'flow', 'global_instruction', 'instruction']:
        if hasattr(agent, key):
          summary[key] = getattr(agent, key)
      st.json(summary)


@st.dialog('Save session')
def save_session_dialog():
  session_name = st.text_input(
      'Session name',
      value=st.session_state.selected_session,
      key='session_name_input_save_session',
  )
  save_button_clicked = st.button('Save', key='save_session_button')

  if save_button_clicked:
    # Define the session file path
    session_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.session.json',
    )

    # Write the session data to the file
    storage_session = st.session_state.session_service.get_session(
        st.session_state.session.app_name,
        st.session_state.session.user_id,
        st.session_state.session.id,
    )
    with open(session_path, 'w') as f:
      f.write(
          strip_bytes_data(copy.deepcopy(storage_session)).model_dump_json(
              indent=2, exclude_none=True
          )
      )
    logs_path = session_path.replace('.session.json', '.logs.json')
    print(st.session_state.call_llm_spans)
    with open(logs_path, 'w') as f:
      json.dump(st.session_state.call_llm_spans, f, indent=2)
    # Provide success feedback to the UI
    st.success(f'Session saved successfully as: {session_path}')


def get_all_agents(agent: BaseAgent, result):
  result[agent.name] = agent
  for sub_agent in agent.sub_agents:
    get_all_agents(sub_agent, result)


# Use demo_name as cache key.
def get_saved_sessions():
  agent_engine_id = st.session_state.agent_engine_id
  if agent_engine_id:
    names = (
        app_context.get_session_service()
        .list_sessions(agent_engine_id, _TEST_USER_ID)
        .session_ids
    )
  else:
    demo_dir = os.path.join(
        app_context.get_agent_folder(), st.session_state.demo_name
    )
    session_suffix = '.session.json'
    names = [
        x.removesuffix(session_suffix)
        for x in os.listdir(demo_dir)
        if x.endswith(session_suffix)
    ]
  names.sort()
  logger.info('Found sessions %s sessions: %s', len(names), names)
  return names


def load_session():
  selected_session = st.session_state.selected_session
  print('load session', selected_session)
  if not selected_session:
    reset_session()
    return

  agent_engine_id = st.session_state.agent_engine_id
  if agent_engine_id:
    st.session_state.session = app_context.get_session_service().get_session(
        agent_engine_id, _TEST_USER_ID, selected_session
    )
    print('loaded session', selected_session)
  else:
    session_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        selected_session + '.session.json',
    )
    with open(session_path, 'r') as f:
      st.session_state.session = Session.model_validate_json(f.read())
      print('loaded session', selected_session)
    logs_path = session_path.replace('.session.json', '.logs.json')
    if os.path.exists(logs_path):
      with open(logs_path, 'r') as f:
        st.session_state.call_llm_spans = json.load(f)
    else:
      st.session_state.call_llm_spans = {}
      st.toast('No logs found for the session.')


def reset_session():
  agent_engine_id = st.session_state.agent_engine_id
  if app_context.is_remote_mode():
    st.session_state.session = app_context.get_session_service().create_session(
        agent_engine_id if agent_engine_id else 'remote_test_app',
        _TEST_USER_ID,
    )
    remote_mode.create_session(
        st.session_state.session.app_name,
        st.session_state.session.user_id,
        st.session_state.session.id,
    )
    logger.info('New session: %s.', st.session_state.session.id)
    return

  app_name: str = (
      agent_engine_id if agent_engine_id else st.session_state.demo_name
  )
  st.session_state.session = app_context.get_session_service().create_session(
      app_name, _TEST_USER_ID
  )
  st.session_state.call_llm_spans = {}
  if initialize_empty_state := create_empty_state(app_context.get_root_agent()):
    app_context.update_session_state(initialize_empty_state)
  logger.info(
      'For app: %s, created new session: %s.',
      app_name,
      st.session_state.session.id,
  )


def import_agent_module(reload=False):
  # The following line is needed to make sure the agent folder is in sys.path.
  app_context.get_agent_folder()
  demo_name = st.session_state.demo_name
  envs.load_dotenv_for_agent(demo_name, app_context.get_agent_folder())
  demo_modules = app_context.get_demo_modules()
  if reload:
    importlib.reload(demo_modules[demo_name].agent)
  else:
    demo_modules[demo_name] = importlib.import_module(demo_name)
  logger.info('Demo loaded: %s', demo_name)


# TODO: temporary for stripping out parts with bytes data
def strip_bytes_data(session: Session):
  for event in session.events:
    if not event.content:
      continue
    event.content.parts = [
        part for part in event.content.parts if not part.inline_data
    ]
    event.actions.artifact_delta = None
  return session


@st.dialog('Debug Info')
def _render_debug_info_dialog():
  st.table(
      pd.DataFrame(
          {
              'Environment Variable': _ENV_VARIABLES.keys(),
              'Value': [
                  os.environ.get(var, '') for var in _ENV_VARIABLES.keys()
              ],
              'Description': _ENV_VARIABLES.values(),
          }
      )
  )
