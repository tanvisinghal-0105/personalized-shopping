# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field

from ..events.event import Event


class Session(BaseModel):
  model_config = ConfigDict(
      extra='forbid',
      arbitrary_types_allowed=True,
  )
  id: str
  app_name: str
  user_id: str
  state: dict[str, Any] = Field(default_factory=dict)
  """The state of the session."""

  events: list[Event] = Field(default_factory=list)
  """The events of the session, e.g. user input, model response, function
  call/response, etc
  """

  last_update_time: float = 0.0
