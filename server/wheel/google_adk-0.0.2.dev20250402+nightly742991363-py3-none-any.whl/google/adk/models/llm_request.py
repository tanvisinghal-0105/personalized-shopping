# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import Optional

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field

from ..tools.base_tool import BaseTool


class LlmRequest(BaseModel):
  model_config = ConfigDict(arbitrary_types_allowed=True)

  model: Optional[str] = None
  contents: list[types.Content] = Field(default_factory=list)
  config: Optional[types.GenerateContentConfig] = None
  live_connect_config: types.LiveConnectConfig = types.LiveConnectConfig()
  """Additional config for the generate content request.

  tools in generate_content_config should not be set.
  """
  tools_dict: dict[str, BaseTool] = Field(default_factory=dict, exclude=True)

  def append_instructions(self, instructions: list[str]) -> None:
    if self.config.system_instruction:
      self.config.system_instruction += '\n\n' + '\n\n'.join(instructions)
    else:
      self.config.system_instruction = '\n\n'.join(instructions)

  def append_tools(self, tools: list[BaseTool]) -> None:
    if not tools:
      return
    declarations = []
    for tool in tools:
      if isinstance(tool, BaseTool):
        declaration = tool._get_declaration()
      else:
        declaration = tool.get_declaration()
      if declaration:
        declarations.append(declaration)
        self.tools_dict[tool.name] = tool
    if declarations:
      self.config.tools.append(types.Tool(function_declarations=declarations))

  def set_output_schema(self, base_model: type[BaseModel]) -> None:
    self.config.response_schema = base_model
    self.config.response_mime_type = 'application/json'
